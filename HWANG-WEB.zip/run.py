from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os

app = Flask(__name__)
@app.route('/product/<int:product_id>')
def product_detail(product_id):
    conn = get_db_connection()
    product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
    conn.close()
    if not product:
        return "Sản phẩm không tồn tại", 404
    return render_template('product_detail.html', product=product)
DB_PATH = os.path.join(os.path.dirname(__file__), 'instance', 'products.db')

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def home():
    conn = get_db_connection()
    products = conn.execute('SELECT * FROM products').fetchall()
    conn.close()
    return render_template('index.html', products=products)

@app.route('/order', methods=['POST'])
@app.route('/order', methods=['POST'])
def order():
    product_id = request.form['product_id']
    name = request.form['name']
    phone = request.form['phone']
    address = request.form['address']
    email = request.form['email']
    print(f"Đơn hàng: {name}, SĐT: {phone}, Địa chỉ: {address}, Email: {email}, Sản phẩm ID: {product_id}")
    return redirect(url_for('home'))

):
    product_id = request.form['product_id']
    name = request.form['name']
    address = request.form['address']
    email = request.form['email']
    print(f"Đơn hàng: {name}, {address}, {email}, sản phẩm ID {product_id}")
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)

from flask import session

app.secret_key = 'hwang-store-key'

@app.route('/add-to-cart/<int:product_id>')
def add_to_cart(product_id):
    cart = session.get('cart', {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    session['cart'] = cart
    return redirect(url_for('cart'))

@app.route('/cart')
def cart():
    cart = session.get('cart', {})
    products_in_cart = []
    total = 0

    if cart:
        conn = get_db_connection()
        for product_id, qty in cart.items():
            product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
            if product:
                products_in_cart.append({
                    'id': product['id'],
                    'name': product['name'],
                    'price': product['price'],
                    'quantity': qty,
                    'image_url': product['image_url'],
                    'subtotal': product['price'] * qty
                })
                total += product['price'] * qty
        conn.close()

    return render_template('cart.html', cart=products_in_cart, total=total)

@app.route('/update-cart/<int:product_id>', methods=['POST'])
def update_cart(product_id):
    quantity = int(request.form.get('quantity', 1))
    cart = session.get('cart', {})
    if quantity <= 0:
        cart.pop(str(product_id), None)
    else:
        cart[str(product_id)] = quantity
    session['cart'] = cart
    return redirect(url_for('cart'))

@app.route('/remove-from-cart/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    cart = session.get('cart', {})
    cart.pop(str(product_id), None)
    session['cart'] = cart
    return redirect(url_for('cart'))